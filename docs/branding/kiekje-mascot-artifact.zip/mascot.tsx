'use client'

import { useState } from 'react'

import styles from './mascot.module.css'

type State = 'idle' | 'capture' | 'success' | 'saving' | 'error'

type props = {
	state?: State
	size?: number
	className?: string
}

export function Mascot({
	state = 'idle',
	size = 320,
	className
}: props) {
	const [current, setCurrent] = useState(state)

	function trigger(next: State) {
		setCurrent(next)

		if (next === 'idle' || next === 'saving') return

		window.setTimeout(function () {
			setCurrent('idle')
		}, 900)
	}

	return (
		<div
			className={`${styles.root} ${className ?? ''}`}
			data-state={current}
			style={{ width: size, height: size }}
			onClick={function () {
				trigger('capture')
			}}
		>
			<img
				src='/mascot/kiekje-icon.png'
				alt='Kiekje mascot'
				className={styles.icon}
				draggable={false}
			/>
		</div>
	)
}
